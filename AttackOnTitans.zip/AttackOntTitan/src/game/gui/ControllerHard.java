package game.gui;

import java.io.IOException;
import java.util.ArrayList;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import game.engine.Battle;
import game.engine.base.Wall;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.weapons.PiercingCannon;
import game.engine.weapons.SniperCannon;
import game.engine.weapons.VolleySpreadCannon;
import game.engine.weapons.WallTrap;


public class ControllerHard {
	@FXML 
	   private AnchorPane HardSceneAnchor;
	   @FXML
	   private AnchorPane Lane1;
	   @FXML
	   private AnchorPane Lane2;
	   @FXML
	   private AnchorPane Lane3;
	   @FXML
	   private AnchorPane Lane4;
	   @FXML
	   private AnchorPane Lane5;
	   @FXML
	   private VBox wall1;
	   @FXML
	   private VBox wall2;
	   @FXML
	   private VBox wall3;
	   @FXML
	   private VBox wall4;
	   @FXML
	   private VBox wall5;
	   @FXML
	    private Label scoreLabel;
	    @FXML
	    private Label resourcesLabel;
	    @FXML
	    private ImageView lane1WallImage;
	    @FXML
	    private ImageView lane2WallImage;
	    @FXML
	    private ImageView lane3WallImage;
	    @FXML
	    private ImageView lane4WallImage;
	    @FXML
	    private ImageView lane5WallImage;
	    @FXML
	    private Label wallHLabel1;
	    @FXML
	    private Label wallHLabel2;
	    @FXML
	    private Label wallHLabel3;
	    @FXML
	    private Label wallHLabel4;
	    @FXML
	    private Label wallHLabel5;
	    @FXML 
	    private Button PassTurn;
	    
	    private Lane lane1;
	    private Lane lane2;
	    private Lane lane3;
	    private Lane lane4;
	    private Lane lane5;
	    
	    @FXML
	    private Label dangerLevel1;
	    @FXML
	    private Label dangerLevel2;
	    @FXML
	    private Label dangerLevel3;
	    @FXML
	    private Label dangerLevel4;
	    @FXML
	    private Label dangerLevel5;
	    
	    @FXML
	    private Button titanbutton;
	    @FXML
	    private ComboBox<String> laneComboBox;
	    
	    
	    
	    @FXML
	  Label Name1;
	  @FXML
	  Label Type1;
	  @FXML
	  Label Price1;
	  @FXML
	  Label DamagePoints1;
	  @FXML
	  Label Name2;
	  @FXML
	  Label Type2;
	  @FXML
	  Label Price2;
	  @FXML
	  Label DamagePoints2;
	  @FXML
	  Label Name3;
	  @FXML
	  Label Type3;
	  @FXML
	  Label Price3;
	  @FXML
	  Label DamagePoints3;
	  @FXML
	  Label Name4;
	  @FXML
	  Label Type4;
	  @FXML
	  Label Price4;
	  @FXML
	  Label DamagePoints4;
	  @FXML
	  Button buyPiercing ;
	  @FXML
	  Button buySniper ;
	  @FXML
	  Button buyVolley ;
	  @FXML
	  Button buyWalltrap ;
	  
	  PiercingCannon piercing;
	  SniperCannon sniper ;
	  VolleySpreadCannon volley ;
	  WallTrap trap ;

    
 
    @FXML
    private Label turnLabel;
    
    @FXML
    private Label phaseLabel;
    
    @FXML
    private Label lanesLabel;
   
    @FXML
    Button passTurn = new Button();
    @FXML
    Button buyPir =new Button();
    
    private Battle hardBattle;
    private Lane selectedLane;
    
    
    


    

    public ControllerHard() {
        // Initialize game logic
       try {
		hardBattle = new Battle(1,0,1500,5,125);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    }
    
    	

    

    
    @FXML
    public void initialize() {
    	
    	  lane1 = hardBattle.getOriginalLanes().get(0);
    	  lane2 = hardBattle.getOriginalLanes().get(1);
    	  lane3 = hardBattle.getOriginalLanes().get(2);
    	  lane4 = hardBattle.getOriginalLanes().get(3);
    	  lane5 = hardBattle.getOriginalLanes().get(4);
    	    updateWallHealthLabels();
      		updateScore();
      		updateResources(); 
      		updateWallHealthLabels();
      		attachEventHandlers();
      		updateTurnLabel();
      		updatePhaseLabel();
      		updateLanesLabel();
      		updateDangerLevel();
    	  ImageView ptitanImageView = new ImageView(TitanImage.getPureTitanImage());
    	  ImageView artitanImageView = new ImageView(TitanImage.getAromredTitanImage());
    	  ImageView abtitanImageView = new ImageView(TitanImage.getAbnormalTitanImage());
    	  ImageView coltitanImageView = new ImageView(TitanImage.getCollosalTitanImage());
    	 
    	  laneComboBox.getItems().addAll("Lane 1", "Lane 2", "Lane 3", "Lane 4", "Lane 5");
    	  laneComboBox.setValue("Lane 1");
    	  
    	 
    	//  selectLane(); 
    	  
    	  passTurn.setOnAction(event -> passTurns());
          buyPir.setOnAction(event->handlebuyPiercing());
    }
    
    
    
    // Method to attach event handlers
    private void attachEventHandlers() {
        // Attach event handlers to each lane
        Lane1.setOnMouseClicked(event -> handleLaneClick(Lane1));
        Lane2.setOnMouseClicked(event -> handleLaneClick(Lane2));
        Lane3.setOnMouseClicked(event -> handleLaneClick(Lane3));
        Lane4.setOnMouseClicked(event -> handleLaneClick(Lane4));
        Lane5.setOnMouseClicked(event -> handleLaneClick(Lane5));
    }

    // Method to handle lane click event
    private void handleLaneClick(AnchorPane lane12) {
        // Example: Handle mouse click on a lane
        System.out.println("Clicked on " + lane12.getId());
    }

    // Example method to update the score display
    public void updateScore() {
        scoreLabel.setText("Score: " + hardBattle.getScore());
    }

    // Example method to update the resources display
    public void updateResources() {
        // Update resources label for each lane
        resourcesLabel.setText("Resources: " + hardBattle.getResourcesGathered());
       
    }
    private void updateTurnLabel() {
        turnLabel.setText("Current Turn: " + hardBattle.getNumberOfTurns());
    }

    // Method to update phase label
    private void updatePhaseLabel() {
        phaseLabel.setText("Current Phase: " + hardBattle.getBattlePhase());
    }

 // Method to update lanes label
    private void updateLanesLabel() {
        lanesLabel.setText("Available Lanes: " + hardBattle.getLanes().size());
    }
    
    private void updateWallHealthLabels() {
    	wallHLabel1.setText("Health: " + lane1.getLaneWall().getCurrentHealth());
    	wallHLabel2.setText("Health: " + lane2.getLaneWall().getCurrentHealth());
    	wallHLabel3.setText("Health: " + lane3.getLaneWall().getCurrentHealth());
    	wallHLabel4.setText("Health: " + lane4.getLaneWall().getCurrentHealth());
    	wallHLabel5.setText("Health: " + lane5.getLaneWall().getCurrentHealth());
    }
    
    private void updateDangerLevel() {
    	dangerLevel1.setText("DangerLevel: " + lane1.getDangerLevel());
    	dangerLevel2.setText("DangerLevel: " + lane2.getDangerLevel());
    	dangerLevel3.setText("DangerLevel: " + lane3.getDangerLevel());
    	dangerLevel4.setText("DangerLevel: " + lane4.getDangerLevel());
    	dangerLevel5.setText("DangerLevel: " + lane5.getDangerLevel());
    }
    
    
    @FXML
    public void passTurns() {
        hardBattle.passTurn();// Perform game turn
        
        updateWallHealthLabels();
    	updateScore();
    	updateResources(); 
    	updateWallHealthLabels();
    	attachEventHandlers();
    	updateTurnLabel();
    	updatePhaseLabel();
    	updateLanesLabel();
    	updateDangerLevel();
    	spawnTitans();
    	
    	
    	
    }
    public Image getTitanImageByCode(int code) {
        switch (code) {
            case 1:
                return TitanImage.getPureTitanImage();
            case 2:
            	return TitanImage.getAbnormalTitanImage();
                
            case 3:
            	return TitanImage.getAromredTitanImage();
            case 4:
                return TitanImage.getCollosalTitanImage();
            default:
                return null; // or a default image
        }
    } 
    public Image getTitanImageByTitan(Titan titan) {
        if (titan instanceof PureTitan) {
            return TitanImage.getPureTitanImage();
        } else if (titan instanceof AbnormalTitan) {
            return TitanImage.getAbnormalTitanImage();
        } else if (titan instanceof ArmoredTitan) { // Assuming you meant ArmoredTitan here
            return TitanImage.getAromredTitanImage();
        } else if (titan instanceof ColossalTitan) { // Assuming you meant ColossalTitan here
            return TitanImage.getCollosalTitanImage();
        } else {
            return null; // or a default image
        }
    }

    private void spawnTitans() {
        
        
	    hardBattle.refillApproachingTitans();
       for(int k =0 ; k< 1 ; k++){
        
        	Image titanImage = getTitanImageByTitan(hardBattle.getApproachingTitans().remove(k));
            
		if (titanImage != null) {
			
				if(!lane1.isLaneLost()){
					lane1.addTitan(hardBattle.getApproachingTitans().get(0));
					   ImageView titanImageView = new ImageView(titanImage);
			             //Set position and add to scene
			           titanImageView.setLayoutX(hardBattle.getTitanSpawnDistance());
			            
			           titanImageView.setLayoutY(-190);
			           
			           TranslateTransition translate = new TranslateTransition();
			           translate.setDuration(Duration.millis(10000));
			           translate.setByX(-1600);
			           translate.setNode(titanImageView);
			           translate.play();
			           
			           HardSceneAnchor.getChildren().add(titanImageView);
        }
				if(!lane2.isLaneLost()){
					lane1.addTitan(hardBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(hardBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(0);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(10000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        HardSceneAnchor.getChildren().add(titanImageView);	  		
	}
				if(!lane3.isLaneLost()){
					lane1.addTitan(hardBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(hardBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(190);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(10000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        HardSceneAnchor.getChildren().add(titanImageView);	  		
	}
				if(!lane4.isLaneLost()){
					lane1.addTitan(hardBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(hardBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(380);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(10000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        HardSceneAnchor.getChildren().add(titanImageView);	  		
	}
				if(!lane5.isLaneLost()){
					lane1.addTitan(hardBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(hardBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(570);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(10000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        HardSceneAnchor.getChildren().add(titanImageView);	  		
	}
		}
				
} 
       }
   
    
   
    @FXML
    private void handlebuyPiercing() {
  
             
            
                try {
					hardBattle.purchaseWeapon(1, selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                updateWallHealthLabels();
            	updateScore();
            	updateResources(); 
            	updateWallHealthLabels();
            	attachEventHandlers();
            	updateTurnLabel();
            	updatePhaseLabel();
            	updateLanesLabel();
            	updateDangerLevel();
            	
                
               
             
                
               
            
    
    }
    @FXML
    private void buySniper() {
  
             
            
                try {
					hardBattle.purchaseWeapon(2, selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                updateWallHealthLabels();
            	updateScore();
            	updateResources(); 
            	updateWallHealthLabels();
            	attachEventHandlers();
            	updateTurnLabel();
            	updatePhaseLabel();
            	updateLanesLabel();
            	updateDangerLevel();
            	
                
               
             
                
               
            
    
    }
    @FXML
    private void buyVolleySpread() {
  
             
            
                try {
					hardBattle.purchaseWeapon(3,selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                updateWallHealthLabels();
            	updateScore();
            	updateResources(); 
            	updateWallHealthLabels();
            	attachEventHandlers();
            	updateTurnLabel();
            	updatePhaseLabel();
            	updateLanesLabel();
            	updateDangerLevel();
            	
                
               
             
                
               
            
    
    }
    @FXML
    private void buyWallTrap() {
  
             
            
                try {
					
					hardBattle.purchaseWeapon(4, selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                updateWallHealthLabels();
            	updateScore();
            	updateResources(); 
            	updateWallHealthLabels();
            	attachEventHandlers();
            	updateTurnLabel();
            	updatePhaseLabel();
            	updateLanesLabel();
            	updateDangerLevel();
            	
                
               
             
                
               
            
    
    }
    

    @FXML
    private void selectLane(ActionEvent e) {
        String selectedLaneName = laneComboBox.getValue();
        switch (selectedLaneName) {
            case "Lane 1":
                selectedLane = lane1;
                break;
            case "Lane 2":
                selectedLane = lane2;
                break;
            case "Lane 3":
                selectedLane = lane3;
                break;
            case "Lane 4":
                selectedLane = lane4;
                break;
            case "Lane 5":
                selectedLane = lane5;
                break;
            default:
                selectedLane = null;
                break;
        }
    }

 // Methods to handle lane selection
 @FXML
 private void selectLane1() {
     selectedLane = lane1;
 }

 @FXML
 private void selectLane2() {
     selectedLane = lane2;
 }

 @FXML
 private void selectLane3() {
     selectedLane = lane3;
 }

 @FXML
 private void selectLane4() {
     selectedLane = lane4;
 }

 @FXML
 private void selectLane5() {
     selectedLane = lane5;
 }

    
}
    
    
    
    

    
    		
    	
    
    
    



