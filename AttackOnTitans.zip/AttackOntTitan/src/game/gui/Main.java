package game.gui;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
    	
        try {
        	
            Parent root = FXMLLoader.load(getClass().getResource("SceneBuilder.fxml"));
            Scene scene = new Scene(root,1920 ,1080);
            String css = this.getClass().getResource("application.css").toExternalForm();
            scene.getStylesheets().add(css);
            Image icon = new Image("Attack on titan logo.png");
            primaryStage.getIcons().add(icon);
            primaryStage.setTitle("Attack on Titan Game");
            primaryStage.centerOnScreen();
            primaryStage.setScene(scene);
            primaryStage.show();
            primaryStage.setFullScreen(true);  
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
        
    public static void main(String[] args) {
        launch(args);
    }
}