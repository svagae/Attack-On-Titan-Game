package game.gui;
import javafx.scene.image.Image;
public class TitanImage {
	
	 
	

	    // Load titan image based on titan name
	    public static Image loadTitanImage(String titanName) {
	        String titanImagePath = "/game/gui/images/" + titanName + ".png"; // Assuming the images are located in this package
	        return new Image(TitanImage.class.getResourceAsStream(titanImagePath));
	    }

	    // Example method to get specific titan image
	    public static Image getPureTitanImage() {
	        return loadTitanImage("pure");
	    }

	    public static Image getAbnormalTitanImage() {
	        return loadTitanImage("abnormal");
	    }

	    public static Image getAromredTitanImage() {
	        return loadTitanImage("aromred");
	    }

	    public static Image getCollosalTitanImage() {
	        return loadTitanImage("Collosal");
	    }

	  
	}



