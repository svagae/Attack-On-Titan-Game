package game.gui;

import game.engine.Battle;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.weapons.PiercingCannon;
import game.engine.weapons.SniperCannon;
import game.engine.weapons.VolleySpreadCannon;
import game.engine.weapons.WallTrap;

import java.io.IOException;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class ControllerEasy {
	
	@FXML 
	   private AnchorPane EasySceneAnchor;
	   @FXML
	   private AnchorPane Lane1;
	   @FXML
	   private AnchorPane Lane2;
	   @FXML
	   private AnchorPane Lane3;
	  
	   @FXML
	   private VBox wall1;
	   @FXML
	   private VBox wall2;
	   @FXML
	   private VBox wall3;
	 
	   @FXML
	    private Label scoreLabel;
	    @FXML
	    private Label resourcesLabel;
	    @FXML
	    private ImageView lane1WallImage;
	    @FXML
	    private ImageView lane2WallImage;
	    @FXML
	    private ImageView lane3WallImage;
	    
	    @FXML
	    private Label wallHLabel1;
	    @FXML
	    private Label wallHLabel2;
	    @FXML
	    private Label wallHLabel3;
	    
	    @FXML 
	    private Button PassTurn;
	    
	    private Lane lane1;
	    private Lane lane2;
	    private Lane lane3;
	   
	    
	    @FXML
	    private Label dangerLevel1;
	    @FXML
	    private Label dangerLevel2;
	    @FXML
	    private Label dangerLevel3;
	    
	    
	    @FXML
	    private ComboBox<String> laneComboBox;
	    
	    
	    
	    @FXML
	  Label Name1;
	  @FXML
	  Label Type1;
	  @FXML
	  Label Price1;
	  @FXML
	  Label DamagePoints1;
	  @FXML
	  Label Name2;
	  @FXML
	  Label Type2;
	  @FXML
	  Label Price2;
	  @FXML
	  Label DamagePoints2;
	  @FXML
	  Label Name3;
	  @FXML
	  Label Type3;
	  @FXML
	  Label Price3;
	  @FXML
	  Label DamagePoints3;
	  @FXML
	  Label Name4;
	  @FXML
	  Label Type4;
	  @FXML
	  Label Price4;
	  @FXML
	  Label DamagePoints4;
	  @FXML
	  Button buyPiercing ;
	  @FXML
	  Button buySniper ;
	  @FXML
	  Button buyVolley ;
	  @FXML
	  Button buyWalltrap ;
	  
	  PiercingCannon piercing;
	  SniperCannon sniper ;
	  VolleySpreadCannon volley ;
	  WallTrap trap ;

 

 @FXML
 private Label turnLabel;
 
 @FXML
 private Label phaseLabel;
 
 @FXML
 private Label lanesLabel;

 @FXML
 Button passTurn = new Button();
 @FXML
 Button buyPir ;
 @FXML
 Button buysnip ;
 @FXML
 Button buyvolley ;
 @FXML
 Button buytrap ;
 
 private Battle EasyBattle;
 private Lane selectedLane;
 
 
 


 

 public ControllerEasy() {
     // Initialize game logic
    try {
		EasyBattle = new Battle(1,0,1500,3,250);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
 
 	

 

 
 @FXML
 public void initialize() {
 	
 	  lane1 = EasyBattle.getOriginalLanes().get(0);
 	  lane2 = EasyBattle.getOriginalLanes().get(1);
 	  lane3 = EasyBattle.getOriginalLanes().get(2);
 	  
 	    updateWallHealthLabels();
   		updateScore();
   		updateResources(); 
   		updateWallHealthLabels();
   		attachEventHandlers();
   		updateTurnLabel();
   		updatePhaseLabel();
   		updateLanesLabel();
   		updateDangerLevel();
 	  ImageView ptitanImageView = new ImageView(TitanImage.getPureTitanImage());
 	  ImageView artitanImageView = new ImageView(TitanImage.getAromredTitanImage());
 	  ImageView abtitanImageView = new ImageView(TitanImage.getAbnormalTitanImage());
 	  ImageView coltitanImageView = new ImageView(TitanImage.getCollosalTitanImage());
 	 
 	  laneComboBox.getItems().addAll("Lane 1", "Lane 2", "Lane 3");
 	  laneComboBox.setValue("Lane 1");
 	  
 	 
 	//  selectLane(); 
 	  
 	  passTurn.setOnAction(event -> passTurns());
       buyPir.setOnAction(event->handlebuyPiercing());
 }
 
 
 
 // Method to attach event handlers
 private void attachEventHandlers() {
     // Attach event handlers to each lane
     Lane1.setOnMouseClicked(event -> handleLaneClick(Lane1));
     Lane2.setOnMouseClicked(event -> handleLaneClick(Lane2));
     Lane3.setOnMouseClicked(event -> handleLaneClick(Lane3));
    
 }

 // Method to handle lane click event
 private void handleLaneClick(AnchorPane lane12) {
     // Example: Handle mouse click on a lane
     System.out.println("Clicked on " + lane12.getId());
 }

 // Example method to update the score display
 public void updateScore() {
     scoreLabel.setText("Score: " + EasyBattle.getScore());
 }

 // Example method to update the resources display
 public void updateResources() {
     // Update resources label for each lane
     resourcesLabel.setText("Resources: " + EasyBattle.getResourcesGathered());
    
 }
 private void updateTurnLabel() {
     turnLabel.setText("Current Turn: " + EasyBattle.getNumberOfTurns());
 }

 // Method to update phase label
 private void updatePhaseLabel() {
     phaseLabel.setText("Current Phase: " + EasyBattle.getBattlePhase());
 }

// Method to update lanes label
 private void updateLanesLabel() {
     lanesLabel.setText("Available Lanes: " + EasyBattle.getLanes().size());
 }
 
 private void updateWallHealthLabels() {
 	wallHLabel1.setText("Health: " + lane1.getLaneWall().getCurrentHealth());
 	wallHLabel2.setText("Health: " + lane2.getLaneWall().getCurrentHealth());
 	wallHLabel3.setText("Health: " + lane3.getLaneWall().getCurrentHealth());
 
 }
 
 private void updateDangerLevel() {
 	dangerLevel1.setText("DangerLevel: " + lane1.getDangerLevel());
 	dangerLevel2.setText("DangerLevel: " + lane2.getDangerLevel());
 	dangerLevel3.setText("DangerLevel: " + lane3.getDangerLevel());
 
 }
 
 
 @FXML
 public void passTurns() {
	 EasyBattle.passTurn();// Perform game turn
     
    updateWallHealthLabels();
 	updateScore();
 	updateResources(); 
 	updateWallHealthLabels();
 	attachEventHandlers();
 	updateTurnLabel();
 	updatePhaseLabel();
 	updateLanesLabel();
 	updateDangerLevel();
 	spawnTitans();
 	
 	
 	
 }
 public Image getTitanImageByCode(int code) {
     switch (code) {
         case 1:
             return TitanImage.getPureTitanImage();
         case 2:
         	return TitanImage.getAbnormalTitanImage();
             
         case 3:
         	return TitanImage.getAromredTitanImage();
         case 4:
             return TitanImage.getCollosalTitanImage();
         default:
             return null; // or a default image
     }
 } 
 public Image getTitanImageByTitan(Titan titan) {
     if (titan instanceof PureTitan) {
         return TitanImage.getPureTitanImage();
     } else if (titan instanceof AbnormalTitan) {
         return TitanImage.getAbnormalTitanImage();
     } else if (titan instanceof ArmoredTitan) { // Assuming you meant ArmoredTitan here
         return TitanImage.getAromredTitanImage();
     } else if (titan instanceof ColossalTitan) { // Assuming you meant ColossalTitan here
         return TitanImage.getCollosalTitanImage();
     } else {
         return null; // or a default image
     }
 }

 private void spawnTitans() {
      
	EasyBattle.refillApproachingTitans();
    for(int k =0 ; k< 1 ; k++){
     
     	Image titanImage = getTitanImageByTitan(EasyBattle.getApproachingTitans().remove(k));
         
		if (titanImage != null) {
			
				if(!lane1.isLaneLost()){
					lane1.addTitan(EasyBattle.getApproachingTitans().get(0));
					   ImageView titanImageView = new ImageView(titanImage);
			             //Set position and add to scene
			           titanImageView.setLayoutX(EasyBattle.getTitanSpawnDistance());
			            
			           titanImageView.setLayoutY(-105);
			           
			           TranslateTransition translate = new TranslateTransition();
			           translate.setDuration(Duration.millis(15000));
			           translate.setByX(-1600);
			           translate.setNode(titanImageView);
			           translate.play();
			           
			           EasySceneAnchor.getChildren().add(titanImageView);
     }
				if(!lane2.isLaneLost()){
					lane1.addTitan(EasyBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(EasyBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(215);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(15000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        EasySceneAnchor.getChildren().add(titanImageView);	  		
	}
				if(!lane3.isLaneLost()){
					lane1.addTitan(EasyBattle.getApproachingTitans().get(0));
					ImageView titanImageView = new ImageView(titanImage);
			        //Set position and add to scene
			        titanImageView.setLayoutX(EasyBattle.getTitanSpawnDistance());
			        titanImageView.setLayoutY(515);
			    
			        TranslateTransition translate = new TranslateTransition();
			        translate.setDuration(Duration.millis(15000));
			        translate.setByX(-1600);
			        translate.setNode(titanImageView);
			        translate.play();
			           
			        EasySceneAnchor.getChildren().add(titanImageView);	  		
	}
		}
				
} 
    }

 

 @FXML
 private void handlebuyPiercing() {

       try {
          	 EasyBattle.purchaseWeapon(1, selectedLane);
	
			} 
       catch (InsufficientResourcesException | InvalidLaneException e) {
					
			e.printStackTrace();
		}
            updateWallHealthLabels();
         	updateScore();
         	updateResources(); 
         	updateWallHealthLabels();
         	attachEventHandlers();
         	updateTurnLabel();
         	updatePhaseLabel();
         	updateLanesLabel();
         	updateDangerLevel();

 }
 @FXML
 private void buySniper() {

             try {
            	 EasyBattle.purchaseWeapon(2, selectedLane);
		
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            updateWallHealthLabels();
         	updateScore();
         	updateResources(); 
         	updateWallHealthLabels();
         	attachEventHandlers();
         	updateTurnLabel();
         	updatePhaseLabel();
         	updateLanesLabel();
         	updateDangerLevel();

 }
 @FXML
 private void buyVolleySpread() {

             try {
            	 EasyBattle.purchaseWeapon(3,selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            updateWallHealthLabels();
         	updateScore();
         	updateResources(); 
         	updateWallHealthLabels();
         	attachEventHandlers();
         	updateTurnLabel();
         	updatePhaseLabel();
         	updateLanesLabel();
         	updateDangerLevel();

 }
 @FXML
 private void buyWallTrap() {

             try {
            	 EasyBattle.purchaseWeapon(4, selectedLane);
					
					
				} catch (InsufficientResourcesException | InvalidLaneException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            updateWallHealthLabels();
         	updateScore();
         	updateResources(); 
         	updateWallHealthLabels();
         	attachEventHandlers();
         	updateTurnLabel();
         	updatePhaseLabel();
         	updateLanesLabel();
         	updateDangerLevel();

 }
 

 @FXML
 private void selectLane(ActionEvent e) {
     String selectedLaneName = laneComboBox.getValue();
     switch (selectedLaneName) {
         case "Lane 1":
             selectedLane = lane1;
             break;
         case "Lane 2":
             selectedLane = lane2;
             break;
         case "Lane 3":
             selectedLane = lane3;
             break;
         default:
             selectedLane = null;
             break;
     }
 }

// Methods to handle lane selection
@FXML
private void selectLane1() {
  selectedLane = lane1;
}

@FXML
private void selectLane2() {
  selectedLane = lane2;
}

@FXML
private void selectLane3() {
  selectedLane = lane3;
}


}
