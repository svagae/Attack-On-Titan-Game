package game.gui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Controller2 {
	
	@FXML
    private AnchorPane scenePane2;
	@FXML
    private Button Easy;
	@FXML
    private Button Hard;
	@FXML
    private Button Back;
	@FXML
    private Button Back1;
	@FXML
    private Stage primaryStage2;
	
	public void setPrimaryStage(Stage primaryStage2) {
        this.primaryStage2 = primaryStage2;
    }
	
	   @FXML
	    public void switchToScene1(ActionEvent event) throws IOException {
	    
	    new SceneSwitch(scenePane2 ,"/game/gui/SceneBuilder.fxml");
	 }
	    
	   
	    @FXML
	    public void Hard(ActionEvent event) throws IOException{
	    	
	     new SceneSwitch(scenePane2 ,"/game/gui/HardScene.fxml");
	    }
	    @FXML
	    public void Easy(ActionEvent event) throws IOException{
	    	new SceneSwitch(scenePane2 ,"/game/gui/EasyScene.fxml");
	    }

}
