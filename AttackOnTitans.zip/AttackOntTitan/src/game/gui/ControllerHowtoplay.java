package game.gui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerHowtoplay {
	
	@FXML
    private Button Back;
	@FXML
    private AnchorPane scenePane3;
	@FXML
	private Stage primaryStage3;

	@FXML
	public void setPrimaryStage(Stage primaryStage3) {
        this.primaryStage3 = primaryStage3;
    }
	 @FXML
	 public void switchToScene1(ActionEvent event) throws IOException {
	    
	    new SceneSwitch(scenePane3 ,"/game/gui/SceneBuilder.fxml");
	 }
	 
	
		
		

}
