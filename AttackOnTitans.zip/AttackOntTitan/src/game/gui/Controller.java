package game.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller {
	
	@FXML
	private Button HowtoplayButton;
	@FXML
    private AnchorPane scenePane;
	@FXML
    private Stage primaryStage;
	@FXML
    private Button ExitButton;
	@FXML
	private ImageView Img1;
	@FXML
	private Button PlayButton;
	
	
	Image Img = new Image(getClass().getResourceAsStream("Eren.jpeg"));

	public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
	
 

    @FXML
    public void switchToPlayScene(ActionEvent event) throws Exception {
       
      new SceneSwitch(scenePane ,"/game/gui/PlayScene.fxml");
    	
    }
    
    
    @FXML
    public void Exit(ActionEvent event) throws IOException {
    	primaryStage = (Stage) scenePane.getScene().getWindow();
    	primaryStage.close();
    }
    
 // Inside your controller class or wherever you handle GUI events

 // Create a method to handle the "How to Play" button click event
    @FXML
    public void handleHowToPlay(ActionEvent event)throws Exception {
	
		new SceneSwitch(scenePane ,"/game/gui/HowToPlayScene.fxml");

    }  
}
    
    
    

    
    
    
