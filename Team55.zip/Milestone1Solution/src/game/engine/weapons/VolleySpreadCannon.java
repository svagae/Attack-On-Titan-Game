package game.engine.weapons;

import game.engine.titans.Titan;


import java.util.PriorityQueue;

public class VolleySpreadCannon extends Weapon
{
	public static final int WEAPON_CODE = 3;

	private final int minRange;
	private final int maxRange;

	public VolleySpreadCannon(int baseDamage, int minRange, int maxRange)
	{
		super(baseDamage);
		this.minRange = minRange;
		this.maxRange = maxRange;
	}

	public int getMinRange()
	{
		return minRange;
	}

	public int getMaxRange()
	{
		return maxRange;
	}

	@Override
	public int turnAttack(PriorityQueue<Titan> laneTitans) {
		int resourcesValue=0;
		PriorityQueue<Titan>RangeOftargets=new PriorityQueue<>(laneTitans);
		while(!RangeOftargets.isEmpty()){
			Titan targetTitan=RangeOftargets.poll();
			int distanceToTitan=targetTitan.getDistance();
			
		if(distanceToTitan>=minRange&&distanceToTitan<=maxRange){
			resourcesValue+=attack(targetTitan);
			
		
		if(targetTitan.isDefeated()){
			laneTitans.remove(targetTitan);
		}
		}
		}
		return resourcesValue;
		
		}
}


