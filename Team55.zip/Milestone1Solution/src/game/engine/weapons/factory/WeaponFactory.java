package game.engine.weapons.factory;

import java.io.IOException;

import game.engine.exceptions.InsufficientResourcesException;

import java.util.HashMap;
import game.engine.dataloader.DataLoader;
import game.engine.weapons.PiercingCannon;
import game.engine.weapons.SniperCannon;
import game.engine.weapons.VolleySpreadCannon;
import game.engine.weapons.WallTrap;
import game.engine.weapons.WeaponRegistry;
import game.engine.weapons.Weapon;

public class WeaponFactory
{
	
	private final HashMap<Integer, WeaponRegistry> weaponShop;

	public WeaponFactory() throws IOException
	{
		super();
		weaponShop = DataLoader.readWeaponRegistry();
	}

	public HashMap<Integer, WeaponRegistry> getWeaponShop()
	{
		return weaponShop;
	}
	
	public FactoryResponse buyWeapon(int resources, int weaponCode) throws InsufficientResourcesException{
		WeaponRegistry w = weaponShop.get(weaponCode);
		if (w.getPrice() > resources) throw new InsufficientResourcesException(resources);
		return new FactoryResponse(w.buildWeapon(), resources- w.getPrice());
	}
	
	public void addWeaponToShop(int code, int price){
		 WeaponRegistry weapon = new WeaponRegistry(code, price); 
	        weaponShop.put(code, weapon); 
	    
	}
	
	
	public void addWeaponToShop(int code, int price, int damage, String name){
		 WeaponRegistry weapon = new WeaponRegistry(code, price ,damage , name); 
	        weaponShop.put(code, weapon); 
	}
	
	public void addWeaponToShop(int code, int price, int damage, String name, int minRange,int maxRange){
		 WeaponRegistry weapon = new WeaponRegistry(code, price ,damage , name ,minRange , maxRange); 
	     weaponShop.put(code, weapon);
	}
				
		
		
		
		
		
	}


