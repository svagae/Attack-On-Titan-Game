package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class SniperCannon extends Weapon
{
	public static final int WEAPON_CODE = 2;

	public SniperCannon(int baseDamage)
	{
		super(baseDamage);
	}

	@Override
	public int turnAttack(PriorityQueue<Titan>  laneTitans) {
		// TODO Auto-generated method stub
		   int resourcesValue = 0;
	        
	        if  (!laneTitans.isEmpty()) {
	            Titan target =  laneTitans.peek(); 
	            resourcesValue += attack(target); // Inflict damage and check for defeat    
	            if  (target.isDefeated()) laneTitans.remove();
	        }
	        
	        return resourcesValue;
	    }	
	}
	


