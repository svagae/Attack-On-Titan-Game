package game.engine.weapons;

import game.engine.interfaces.Attackee;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class WallTrap extends Weapon
{
	public static final int WEAPON_CODE = 4;

	public WallTrap(int baseDamage)
	{
		super(baseDamage);
	}

	@Override
	public int turnAttack(PriorityQueue<Titan> laneTitans) {
		// TODO Auto-generated method stub
		
	    if (laneTitans.isEmpty()) {
	        return 0; 
	    }
	    
	    
	    int resourcesValue = 0;

	    Titan nearestTitan = laneTitans.peek(); 
	    int nearDistance = nearestTitan.getDistance(); 

	    
	    if (nearestTitan.hasReachedTarget()) {
	        Titan target = laneTitans.peek(); 
	        resourcesValue = attack(target); 
	        if (target.isDefeated()) {
	            laneTitans.remove(target);
	        }
	    }

	    return resourcesValue;
	}

	@Override
	public int attack(Attackee target) {
		// TODO Auto-generated method stub
		return super.attack(target);
	}
	
}
