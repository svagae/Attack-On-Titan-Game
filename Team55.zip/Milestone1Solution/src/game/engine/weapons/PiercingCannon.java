package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.ArrayList;
import java.util.PriorityQueue;

public class PiercingCannon extends Weapon
{
	public static final int WEAPON_CODE = 1;

	public PiercingCannon(int baseDamage)
	{
		super(baseDamage);
	}
	
	
	

	@Override
	public int turnAttack(PriorityQueue<Titan> laneTitans) {
		// TODO Auto-generated method stub
		int resourcesValue =0;
		 PriorityQueue<Titan> tmp = new PriorityQueue<>(laneTitans);
		 ArrayList<Titan> defeatedTitans = new ArrayList<>();
		for(int i =0;i<5&& ! tmp.isEmpty();i++){
			Titan target=tmp.poll();
			
			resourcesValue+=attack(target);
			if(target.isDefeated()){
				defeatedTitans.add(target);
				
			}
			
		}
		laneTitans.removeAll(defeatedTitans);
		return resourcesValue;
	}
	
	
	

}
