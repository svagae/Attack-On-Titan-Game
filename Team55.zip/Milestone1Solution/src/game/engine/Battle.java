package game.engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;

import game.engine.base.Wall;
import game.engine.dataloader.DataLoader;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.Titan;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.Weapon;
import game.engine.weapons.WeaponRegistry;
import game.engine.weapons.factory.FactoryResponse;
import game.engine.weapons.factory.WeaponFactory;

public class Battle
{
	private static final int[][] PHASES_APPROACHING_TITANS =
	{
		{ 1, 1, 1, 2, 1, 3, 4 },
		{ 2, 2, 2, 1, 3, 3, 4 },
		{ 4, 4, 4, 4, 4, 4, 4 } 
	}; // order of the types of titans (codes) during each phase
	private static final int WALL_BASE_HEALTH = 10000;

	private int numberOfTurns;
	private int resourcesGathered;
	private BattlePhase battlePhase;
	private int numberOfTitansPerTurn; // initially equals to 1
	private int score; // Number of Enemies Killed
	private int titanSpawnDistance;
	private final WeaponFactory weaponFactory;
	private final HashMap<Integer, TitanRegistry> titansArchives;
	private final ArrayList<Titan> approachingTitans; // treated as a Queue
	private final PriorityQueue<Lane> lanes;
	private final ArrayList<Lane> originalLanes;

	public Battle(int numberOfTurns, int score, int titanSpawnDistance, int initialNumOfLanes,
			int initialResourcesPerLane) throws IOException
	{
		super();
		this.numberOfTurns = numberOfTurns;
		this.battlePhase = BattlePhase.EARLY;
		this.numberOfTitansPerTurn = 1;
		this.score = score;
		this.titanSpawnDistance = titanSpawnDistance;
		this.resourcesGathered = initialResourcesPerLane * initialNumOfLanes;
		this.weaponFactory = new WeaponFactory();
		this.titansArchives = DataLoader.readTitanRegistry();
		this.approachingTitans = new ArrayList<Titan>();
		this.lanes = new PriorityQueue<>();
		this.originalLanes = new ArrayList<>();
		this.initializeLanes(initialNumOfLanes);
	}

	public int getNumberOfTurns()
	{
		return numberOfTurns;
	}

	public void setNumberOfTurns(int numberOfTurns)
	{
		this.numberOfTurns = numberOfTurns;
	}

	public int getResourcesGathered()
	{
		return resourcesGathered;
	}

	public void setResourcesGathered(int resourcesGathered)
	{
		this.resourcesGathered = resourcesGathered;
	}

	public BattlePhase getBattlePhase()
	{
		return battlePhase;
	}

	public void setBattlePhase(BattlePhase battlePhase)
	{
		this.battlePhase = battlePhase;
	}

	public int getNumberOfTitansPerTurn()
	{
		return numberOfTitansPerTurn;
	}

	public void setNumberOfTitansPerTurn(int numberOfTitansPerTurn)
	{
		this.numberOfTitansPerTurn = numberOfTitansPerTurn;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int score)
	{
		this.score = score;
	}

	public int getTitanSpawnDistance()
	{
		return titanSpawnDistance;
	}

	public void setTitanSpawnDistance(int titanSpawnDistance)
	{
		this.titanSpawnDistance = titanSpawnDistance;
	}

	public WeaponFactory getWeaponFactory()
	{
		return weaponFactory;
	}

	public HashMap<Integer, TitanRegistry> getTitansArchives()
	{
		return titansArchives;
	}

	public ArrayList<Titan> getApproachingTitans()
	{
		return approachingTitans;
	}

	public PriorityQueue<Lane> getLanes()
	{
		return lanes;
	}

	public ArrayList<Lane> getOriginalLanes()
	{
		return originalLanes;
	}

	private void initializeLanes(int numOfLanes)
	{
		for (int i = 0; i < numOfLanes; i++)
		{
			Wall w = new Wall(WALL_BASE_HEALTH);
			Lane l = new Lane(w);

			this.getOriginalLanes().add(l);
			this.getLanes().add(l);
		}
	}
	public void refillApproachingTitans() {
	    if (battlePhase == null) {
	        System.err.println("Error: battlePhase is null");
	        return;
	    }
	    
	    int indexPhase = battlePhase.ordinal();
	    if (indexPhase < 0 || indexPhase >= PHASES_APPROACHING_TITANS.length) {
	        System.err.println("Error: Invalid battle phase index");
	      
	    }

	    int[] titanCodes = PHASES_APPROACHING_TITANS[indexPhase];
	    if (titanCodes == null) {
	        System.err.println("Error: Titan codes for the current phase are null");
	        return;
	    }

	    for (int i = 0; i < titanCodes.length; i++) {
	        int code = titanCodes[i];
	        if (!titansArchives.containsKey(code)) {
	            System.err.println("Error: Titan registry not found for code " + code);
	            continue;
	        }
	        TitanRegistry titanRegister = titansArchives.get(code);
	        if (titanRegister == null) {
	            System.err.println("Error: Titan registry is null for code " + code);
	            continue;
	        }
	        approachingTitans.add(titanRegister.spawnTitan(getTitanSpawnDistance()));
	    }
	}

			
	
	private void addTurnTitansToLane()
	{
		
		Lane leastDangerous = lanes.peek(); 
		for(int i=0; i<numberOfTitansPerTurn; i++)
		{
			if(approachingTitans.isEmpty()) refillApproachingTitans();
	        leastDangerous.addTitan(approachingTitans.remove(0));
		}
		
		leastDangerous.updateLaneDangerLevel();
	}
	// A method that performs the move action
	private void moveTitans(){
		PriorityQueue<Lane> temp = new PriorityQueue<Lane>();
		while(!lanes.isEmpty()){
			Lane l = lanes.poll();
			l.moveLaneTitans();
			temp.add(l);
		}
		while(!temp.isEmpty()) lanes.add(temp.poll());
	}
	private int performWeaponsAttacks() {
	    int totalResources = 0;
	    Iterator<Lane> iterator = lanes.iterator();
	    while (iterator.hasNext()) {
	        Lane lane = iterator.next();
	        if (lane.isLaneLost()) {
	            iterator.remove(); // Remove lost lanes
	        } else {
	            int resourceCollected = lane.performLaneWeaponsAttacks();
	            totalResources += resourceCollected;
	        }
	    }
	    setResourcesGathered(totalResources + getResourcesGathered());
	    this.score += totalResources;
	    return totalResources;
	}


	private int performTitansAttacks() {
	    int totalResources = 0;
	    PriorityQueue<Lane> temp = new PriorityQueue<Lane>();
		while(!lanes.isEmpty()){
			Lane currentLane = lanes.remove();
		    
	        int resourceValue = currentLane.performLaneTitansAttacks();
	        totalResources += resourceValue;
	        if (!currentLane.isLaneLost()) {
	        	temp.offer(currentLane);
	        }
		}
		while(!temp.isEmpty()) lanes.add(temp.poll());
	    
	
	    return totalResources;
	}
	private void updateLanesDangerLevels() {
		PriorityQueue<Lane> temp = new PriorityQueue<Lane>();
		while(!lanes.isEmpty()){
			Lane l = lanes.poll();
			l.updateLaneDangerLevel();
			temp.add(l);
		}
		while(!temp.isEmpty()) lanes.add(temp.poll());
	    //for(Lane lane :lanes)	lane.updateLaneDangerLevel();
	}
	private void finalizeTurns() {
	    numberOfTurns++;
	    
	    if (numberOfTurns < 15) {
	    	
	        battlePhase = BattlePhase.EARLY;
	    } else if (numberOfTurns < 30) {
	    	
	        battlePhase = BattlePhase.INTENSE;
	    } else {
	    	
	    	 battlePhase = BattlePhase.GRUMBLING;
	         if (numberOfTurns == 30) { 
	             
	         } else 
	         {
	             
	             if ((numberOfTurns - 30) % 5 == 0 && numberOfTurns != 30) {
	                 numberOfTitansPerTurn *= 2;
	             }
	           }
	         }
	 }
	private void performTurn() {
	  
	    moveTitans();
	    performWeaponsAttacks();
	    performTitansAttacks();
	    addTurnTitansToLane();
	    finalizeTurns();
	    updateLanesDangerLevels();
	    
	}
	public boolean isGameOver() {
	    for (Lane lane : originalLanes) {
	        if (!lane.isLaneLost()) { 
	            return false;
	        }
	    }
	     return true;
	}


	public void passTurn() {
	   performTurn();
	}
	public void purchaseWeapon(int weaponCode, Lane lane) throws InsufficientResourcesException, InvalidLaneException, IOException {
	    if (lane.isLaneLost()) {
	    	
	        throw new InvalidLaneException("Action done on an invalid lane");
	    }
	    if (!lanes.contains(lane)) {
	    	
	        throw new InvalidLaneException("Action done on an invalid lane");
	    }
	    if (!originalLanes.contains(lane)) {
	    	
	        throw new InvalidLaneException("Action done on an invalid lane");
	    }
	    HashMap<Integer, WeaponRegistry> weaponShop = getWeaponFactory().getWeaponShop();
	    WeaponRegistry weaponRegistry = weaponShop.get(weaponCode);
//	    if (weaponRegistry == null) {
//	    	throw new InvalidLaneException("Action done on an invalid lane");
//	    }
	    int weaponPrice = weaponRegistry.getPrice();
	    if (getResourcesGathered() < weaponPrice) {
	        throw new InsufficientResourcesException("Not enough resources, resources provided = "+getResourcesGathered());
	        
	    }

	    WeaponFactory f = new WeaponFactory();
	    Weapon weapon = f.buyWeapon(resourcesGathered, weaponCode).getWeapon();
	    lane.addWeapon(weapon);
	    resourcesGathered -= weaponPrice;

	    passTurn();
	}




	

	

	
	
	}

	
	
	



