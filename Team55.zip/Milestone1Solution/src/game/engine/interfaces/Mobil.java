package game.engine.interfaces;

public interface Mobil
{
	int getDistance();

	void setDistance(int distance);

	int getSpeed();

	void setSpeed(int speed);
	
	    
    default boolean hasReachedTarget() {
    	int distance = getDistance();
    	return distance<=0;
    }
    default boolean move(){
    	int distance=getDistance();
    	int speed=getSpeed();
    	
    	if (speed==0){
    		return false;
    	}
    	else{
    		setDistance(distance-speed);
    		if (hasReachedTarget()){
    			return true;
    		}
    		else{
    			return false;
    		}
    	}
    }
	       
 }



