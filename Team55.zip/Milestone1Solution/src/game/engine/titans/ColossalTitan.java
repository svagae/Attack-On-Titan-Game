package game.engine.titans;

import game.engine.interfaces.Mobil;



public class ColossalTitan extends Titan
{
	public static final int TITAN_CODE = 4;

	public ColossalTitan(int baseHealth, int baseDamage, int heightInMeters, int distanceFromBase, int speed,
			int resourcesValue, int dangerLevel)
	{
		super(baseHealth, baseDamage, heightInMeters, distanceFromBase, speed, resourcesValue, dangerLevel);
		
	}

	@Override
    public boolean move() {
    // TODO Auto-generated method stub
	    int speed=super.getSpeed();
	    boolean moveAction = super.move(); // Store the result of super.move()
        //if (moveAction) { // If the move action was successful
            speed +=1; // Increment the speed by 1 "Distance Unit"
            setSpeed(speed);
        //}
        return moveAction; // Return the result of the move action    
    }
}
	

	

